# Judo — iOS (SwiftUI) sürümü

JarvisAndroid V73 (Gemini) projesinin iOS uyarlaması. Android'deki Kotlin/Compose kodunun
iOS'ta karşılığı olan çekirdek kısmı SwiftUI'a taşındı.

## Taşınanlar
| Android | iOS |
|---|---|
| ApiKeyScreen + SecureKeyStore (Keystore) | `ApiKeyView` + `KeychainStore` |
| GeminiClient (OpenAI uyumlu uç nokta, gemini-2.5-flash) | `GeminiClient` (araç çağırma döngüsü dahil) |
| MemoryStore / MemoryScreen | `MemoryStore` / `MemoryView` |
| WeatherClient | `Tools.get_weather` (Open-Meteo) |
| VoiceEngine (TTS/STT) | `SpeechManager` (AVSpeechSynthesizer + SFSpeechRecognizer, tr-TR) |
| JarvisOrb | `OrbView` (Canvas) |
| MainScreen, kamera/fotoğraf ekleme, yan menü | `MainView`, `CameraPicker`, `SideMenu` |
| Tema renkleri, ikon | `Theme`, `AppIcon` (aynı ikon) |

## iOS'ta karşılığı OLMAYANLAR (taşınmadı)
AccessibilityService / MiniWindow / uygulama otomasyonu, uyandırma kelimesi arka plan servisi,
telefon kontrolü, SMS/sosyal mesaj gönderme, ekran yakalama servisi, Android TV Remote,
MusicService/NewPipe, BootReceiver, Terminal. iOS bunlara izin vermez.
Takvim, hatırlatıcı (EventKit / UNUserNotification), web arama ve el hareketi (MediaPipe) sonradan eklenebilir.

## Derleme
GitHub'a yükle → Actions → "Build iOS IPA" → Artifacts → `Jarvis-ipa`.
- `Jarvis-unsigned.ipa`: imzasız; AltStore / Sideloadly / TrollStore ile yüklenir.
- `Jarvis-signed.ipa`: yalnızca secret'lar tanımlıysa (workflow başındaki yoruma bak).

Yerelde: `brew install xcodegen && xcodegen generate && open Jarvis.xcodeproj`

NOT: Sandbox'ta Swift derleyicisi yok; kod DERLENMEDİ. Hata çıkarsa Actions logunu ilet.
