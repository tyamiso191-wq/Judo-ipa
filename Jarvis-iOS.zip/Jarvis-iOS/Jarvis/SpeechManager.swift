import Foundation
import AVFoundation
import Speech

/// Sesli okuma (TTS) + mikrofonla dinleme (STT). Android VoiceEngine.kt'nin iOS karşılığı.
final class SpeechManager: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var isSpeaking = false
    @Published var isListening = false
    @Published var level: Float = 0
    @Published var partial = ""

    var rate: Float = 0.5
    var onFinalTranscript: ((String) -> Void)?

    private let synth = AVSpeechSynthesizer()
    private let engine = AVAudioEngine()
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "tr-TR"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var silenceWork: DispatchWorkItem?

    override init() {
        super.init()
        synth.delegate = self
    }

    // MARK: TTS

    func speak(_ text: String) {
        let clean = text.replacingOccurrences(of: "*", with: "").replacingOccurrences(of: "#", with: "")
        guard !clean.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? AVAudioSession.sharedInstance().setActive(true)
        let u = AVSpeechUtterance(string: clean)
        u.voice = AVSpeechSynthesisVoice(language: "tr-TR")
        u.rate = rate
        DispatchQueue.main.async { self.isSpeaking = true }
        synth.speak(u)
    }

    func stopSpeaking() {
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        DispatchQueue.main.async { self.isSpeaking = false }
    }

    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) {
        DispatchQueue.main.async { self.isSpeaking = false }
    }
    func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) {
        DispatchQueue.main.async { self.isSpeaking = false }
    }

    // MARK: STT

    func toggleListening() {
        isListening ? stopListening(deliver: true) : requestAndStart()
    }

    private func requestAndStart() {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else { return }
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                guard granted else { return }
                DispatchQueue.main.async { self.startListening() }
            }
        }
    }

    private func startListening() {
        stopSpeaking()
        guard let recognizer = recognizer, recognizer.isAvailable else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: .duckOthers)
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            let req = SFSpeechAudioBufferRecognitionRequest()
            req.shouldReportPartialResults = true
            request = req
            partial = ""

            let input = engine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buf, _ in
                self?.request?.append(buf)
                guard let ch = buf.floatChannelData?[0] else { return }
                let n = Int(buf.frameLength)
                var sum: Float = 0
                for i in 0..<n { sum += ch[i] * ch[i] }
                let rms = n > 0 ? sqrt(sum / Float(n)) : 0
                DispatchQueue.main.async { self?.level = min(1, rms * 8) }
            }
            engine.prepare()
            try engine.start()
            isListening = true

            task = recognizer.recognitionTask(with: req) { [weak self] result, error in
                guard let self = self else { return }
                if let r = result {
                    DispatchQueue.main.async {
                        self.partial = r.bestTranscription.formattedString
                        self.armSilenceTimer()
                        if r.isFinal { self.stopListening(deliver: true) }
                    }
                }
                if error != nil {
                    DispatchQueue.main.async { self.stopListening(deliver: true) }
                }
            }
            armSilenceTimer()
        } catch {
            stopListening(deliver: false)
        }
    }

    /// Konuşma 1,6 sn kesilirse dinlemeyi bitirir.
    private func armSilenceTimer() {
        silenceWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.stopListening(deliver: true) }
        silenceWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6, execute: w)
    }

    func stopListening(deliver: Bool) {
        guard isListening else { return }
        silenceWork?.cancel()
        let text = partial.trimmingCharacters(in: .whitespacesAndNewlines)
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil
        task = nil
        isListening = false
        level = 0
        partial = ""
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        if deliver, !text.isEmpty { onFinalTranscript?(text) }
    }
}
