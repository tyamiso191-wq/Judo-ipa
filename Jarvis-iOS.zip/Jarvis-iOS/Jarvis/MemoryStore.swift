import Foundation

/// Kalıcı uzun-vadeli hafıza (Android MemoryStore.kt karşılığı). UserDefaults + JSON.
struct MemoryItem: Codable, Identifiable, Equatable {
    var id: String
    var text: String
    var savedAt: Date
}

enum MemoryStore {
    private static let key = "jarvis_memory_items"
    private static let maxItems = 200
    private static let lock = NSLock()

    static func list() -> [MemoryItem] {
        lock.lock(); defer { lock.unlock() }
        guard let data = UserDefaults.standard.data(forKey: key),
              let items = try? JSONDecoder().decode([MemoryItem].self, from: data) else { return [] }
        return items
    }

    private static func save(_ items: [MemoryItem]) {
        lock.lock(); defer { lock.unlock() }
        if let data = try? JSONEncoder().encode(Array(items.suffix(maxItems))) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    @discardableResult
    static func add(_ text: String) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let id = "m\(Int(Date().timeIntervalSince1970 * 1000))"
        save(list() + [MemoryItem(id: id, text: t, savedAt: Date())])
        return id
    }

    /// id ile ya da metne göre (içeren, büyük/küçük harf duyarsız) siler. Silinen sayısını döndürür.
    @discardableResult
    static func delete(_ idOrQuery: String) -> Int {
        let current = list()
        let q = idOrQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var remove = current.filter { $0.id == idOrQuery }
        if remove.isEmpty && !q.isEmpty {
            remove = current.filter { $0.text.lowercased().contains(q) }
        }
        if remove.isEmpty { return 0 }
        let ids = Set(remove.map { $0.id })
        save(current.filter { !ids.contains($0.id) })
        return remove.count
    }

    static func clear() { save([]) }
}
