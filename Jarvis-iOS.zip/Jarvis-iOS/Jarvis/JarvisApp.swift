import SwiftUI

@main
struct JarvisApp: App {
    @StateObject private var vm = ChatViewModel()

    var body: some Scene {
        WindowGroup {
            Group {
                if vm.apiKey == nil {
                    ApiKeyView()
                } else {
                    MainView()
                }
            }
            .environmentObject(vm)
            .preferredColorScheme(.dark)
        }
    }
}
