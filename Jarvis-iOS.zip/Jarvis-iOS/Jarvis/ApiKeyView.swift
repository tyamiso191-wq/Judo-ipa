import SwiftUI

struct ApiKeyView: View {
    @EnvironmentObject var vm: ChatViewModel
    @State private var key = ""

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 14) {
                Text("◈ Judo")
                    .font(.system(size: 26, weight: .bold))
                    .tracking(4)
                    .foregroundColor(Theme.teal)
                Text("Başlamak için Google Gemini API anahtarını gir. Anahtarı Google AI Studio'dan ücretsiz alabilirsin.")
                    .font(.system(size: 13))
                    .foregroundColor(Theme.dim)
                    .multilineTextAlignment(.center)

                SecureField("Gemini API anahtarı (AIza…)", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(12)
                    .foregroundColor(Theme.text)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.tealDim, lineWidth: 1))
                    .padding(.top, 10)

                Button {
                    if !key.trimmingCharacters(in: .whitespaces).isEmpty { vm.saveKey(key) }
                } label: {
                    Text(vm.keyCheck == .checking ? "DOĞRULANIYOR…" : "DOĞRULA VE BAŞLAT")
                        .font(.system(size: 14, weight: .bold))
                        .tracking(2)
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(Theme.teal)
                        .foregroundColor(Theme.bg)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .disabled(vm.keyCheck == .checking)

                if case .error(let msg) = vm.keyCheck {
                    Text(msg).font(.system(size: 12)).foregroundColor(Theme.red).multilineTextAlignment(.center)
                }

                Link("Anahtar al: aistudio.google.com/apikey",
                     destination: URL(string: "https://aistudio.google.com/apikey")!)
                    .font(.system(size: 11)).foregroundColor(Theme.teal)

                Text("Anahtar doğrulanır ve yalnızca bu telefonda, iOS Keychain ile şifreli saklanır. Kullanımın Google hesabındaki Gemini kotasına yazılır.")
                    .font(.system(size: 10))
                    .foregroundColor(Theme.dim.opacity(0.7))
                    .multilineTextAlignment(.center)
            }
            .padding(28)
            .background(Theme.panel)
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .padding(24)
        }
    }
}
