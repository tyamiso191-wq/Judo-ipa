import SwiftUI

struct MemoryView: View {
    @State private var items = MemoryStore.list()
    @State private var newNote = ""

    var body: some View {
        List {
            Section {
                HStack {
                    TextField("Yeni not…", text: $newNote)
                    Button("Ekle") {
                        guard !newNote.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                        MemoryStore.add(newNote); newNote = ""; items = MemoryStore.list()
                    }
                }
            }
            Section {
                if items.isEmpty {
                    Text("Hafıza boş.").foregroundColor(Theme.dim)
                }
                ForEach(items) { it in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(it.text).foregroundColor(Theme.text)
                        Text(it.savedAt.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption2).foregroundColor(Theme.dim)
                    }
                }
                .onDelete { idx in
                    idx.map { items[$0].id }.forEach { MemoryStore.delete($0) }
                    items = MemoryStore.list()
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(Theme.background.ignoresSafeArea())
        .navigationTitle("Hafıza")
        .navigationBarTitleDisplayMode(.inline)
    }
}
