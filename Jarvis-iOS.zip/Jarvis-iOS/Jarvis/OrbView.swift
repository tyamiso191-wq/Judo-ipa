import SwiftUI

/// Radar / yıldız haritası orb'u (Android JarvisOrb.kt'nin Canvas karşılığı).
struct OrbView: View {
    var state: OrbState
    var level: CGFloat = 0

    private struct Star { let angle, r, size, phase, speed, alpha: Double }

    private static let stars: [Star] = {
        var seed: UInt64 = 42
        func next() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 33) / Double(1 << 31)
        }
        return (0..<70).map { _ in
            Star(angle: next() * .pi * 2, r: 0.12 + next() * 0.88, size: 1 + next() * 2.2,
                 phase: next() * .pi * 2, speed: 0.5 + next() * 1.6, alpha: 0.25 + next() * 0.55)
        }
    }()

    var body: some View {
        TimelineView(.animation) { tl in
            Canvas { ctx, size in
                let t = tl.date.timeIntervalSinceReferenceDate
                let c = CGPoint(x: size.width / 2, y: size.height / 2)
                let base = min(size.width, size.height) / 2 - 6
                let pulse = 1 + Double(level) * 0.06 + (state == .thinking ? 0.02 * sin(t * 6) : 0)
                let R = base * pulse
                let col = state.color

                // Eş merkezli halkalar
                for i in 1...4 {
                    let r = R * Double(i) / 4
                    ctx.stroke(Path(ellipseIn: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2)),
                               with: .color(col.opacity(i == 4 ? 0.55 : 0.18)), lineWidth: i == 4 ? 1.5 : 1)
                }

                // Dönen kırık dış tık halkası
                var ticks = ctx
                ticks.translateBy(x: c.x, y: c.y)
                ticks.rotate(by: .radians(t * 0.25))
                let rr = R + 3
                ticks.stroke(Path(ellipseIn: CGRect(x: -rr, y: -rr, width: rr * 2, height: rr * 2)),
                             with: .color(col.opacity(0.5)),
                             style: StrokeStyle(lineWidth: 2, lineCap: .round, dash: [3, 12]))

                // Radar süpürmesi
                let sweep = t * (state == .thinking ? 2.4 : 1.1)
                for k in 0..<28 {
                    let a = sweep - Double(k) * 0.035
                    var p = Path()
                    p.move(to: c)
                    p.addLine(to: CGPoint(x: c.x + cos(a) * R, y: c.y + sin(a) * R))
                    ctx.stroke(p, with: .color(col.opacity(0.35 * (1 - Double(k) / 28))), lineWidth: 2)
                }

                // Titreyen noktalar
                for s in Self.stars {
                    let tw = 0.5 + 0.5 * sin(t * s.speed + s.phase)
                    let x = c.x + cos(s.angle) * R * s.r
                    let y = c.y + sin(s.angle) * R * s.r
                    ctx.fill(Path(ellipseIn: CGRect(x: x - s.size / 2, y: y - s.size / 2, width: s.size, height: s.size)),
                             with: .color(col.opacity(s.alpha * (0.35 + 0.65 * tw))))
                }

                // Merkez
                let core = R * 0.12 * (1 + Double(level) * 0.8)
                ctx.fill(Path(ellipseIn: CGRect(x: c.x - core, y: c.y - core, width: core * 2, height: core * 2)),
                         with: .color(col.opacity(0.9)))
            }
        }
    }
}
