import SwiftUI
import UIKit
import Combine

struct ChatMessage: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String          // "user" | "assistant"
    var text: String
    var imageData: Data? = nil
    var date = Date()
}

enum KeyCheck: Equatable {
    case idle, checking, error(String)
}

enum OrbState {
    case idle, listening, thinking, speaking
    var color: Color {
        switch self {
        case .idle: return Theme.teal
        case .listening: return Theme.green
        case .thinking: return Theme.gold
        case .speaking: return Theme.blue
        }
    }
}

@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isBusy = false
    @Published var apiKey: String?
    @Published var keyCheck: KeyCheck = .idle
    @Published var speakReplies: Bool {
        didSet { UserDefaults.standard.set(speakReplies, forKey: "speak_replies") }
    }
    @Published var speechRate: Double {
        didSet { UserDefaults.standard.set(speechRate, forKey: "speech_rate"); speech.rate = Float(speechRate) }
    }

    let speech = SpeechManager()
    private let client = GeminiClient()
    private let keyAccount = "gemini_api_key"
    private let historyKey = "chat_history_v1"

    var orbState: OrbState {
        if speech.isListening { return .listening }
        if isBusy { return .thinking }
        if speech.isSpeaking { return .speaking }
        return .idle
    }

    init() {
        let d = UserDefaults.standard
        speakReplies = d.object(forKey: "speak_replies") as? Bool ?? true
        speechRate = d.object(forKey: "speech_rate") as? Double ?? 0.5
        apiKey = KeychainStore.get(keyAccount)
        speech.rate = Float(speechRate)
        if let data = d.data(forKey: historyKey),
           let saved = try? JSONDecoder().decode([ChatMessage].self, from: data) {
            messages = saved
        }
        speech.onFinalTranscript = { [weak self] text in
            Task { @MainActor in self?.send(text, image: nil) }
        }
        speech.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }.store(in: &bag)
    }

    private var bag = Set<AnyCancellable>()

    // MARK: Anahtar

    func saveKey(_ raw: String) {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        keyCheck = .checking
        Task {
            switch await client.validate(key) {
            case .valid:
                KeychainStore.set(key, for: keyAccount)
                apiKey = key
                keyCheck = .idle
            case .invalid(let m), .unreachable(let m):
                keyCheck = .error(m)
            }
        }
    }

    func resetKey() {
        KeychainStore.delete(keyAccount)
        apiKey = nil
        keyCheck = .idle
    }

    // MARK: Sohbet

    func send(_ raw: String, image: UIImage?) {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (!text.isEmpty || image != nil), !isBusy, let key = apiKey else { return }
        speech.stopSpeaking()
        messages.append(ChatMessage(role: "user",
                                    text: text.isEmpty ? "Bu fotoğrafı incele." : text,
                                    imageData: image?.resizedJPEG(maxSide: 1280)))
        isBusy = true
        let history = Array(messages.suffix(30))
        Task {
            do {
                let reply = try await client.chat(key: key, system: systemPrompt(),
                                                  history: history, tools: Tools.definitions,
                                                  runTool: { name, args in await Tools.run(name, args) })
                messages.append(ChatMessage(role: "assistant", text: reply))
                if speakReplies { speech.speak(reply) }
            } catch {
                let msg = error.localizedDescription
                messages.append(ChatMessage(role: "assistant", text: "⚠︎ \(msg)"))
                if case LlmError.auth = error { resetKey() }
            }
            isBusy = false
            persist()
        }
    }

    func clearChat() {
        speech.stopSpeaking()
        messages = []
        persist()
    }

    private func persist() {
        let slim = messages.suffix(100).map { m -> ChatMessage in var c = m; c.imageData = nil; return c }
        if let data = try? JSONEncoder().encode(Array(slim)) {
            UserDefaults.standard.set(data, forKey: historyKey)
        }
    }

    // MARK: Sistem istemi

    private func systemPrompt() -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "tr_TR")
        f.dateFormat = "d MMMM yyyy EEEE, HH:mm"
        UIDevice.current.isBatteryMonitoringEnabled = true
        let b = UIDevice.current.batteryLevel
        let battery = b >= 0 ? "%\(Int(b * 100))" : "bilinmiyor"
        let mem = MemoryStore.list()
        let memBlock = mem.isEmpty ? "(boş)" : mem.map { "- [\($0.id)] \($0.text)" }.joined(separator: "\n")

        return """
        Adın Judo — bu sadece bir isim/stil tercihi. Iron Man karakterini OYNAMA; Tony Stark, zırh, süper kahramanlık gibi göndermeler yapma. Gündelik işlerde yardımcı olan sıradan, normal bir kişisel asistansın.
        Türkçe konuş, kısa ve net cevap ver (birkaç cümleyi geçme, cevabın sesli okunacak). Markdown, yıldız, madde işareti KULLANMA; sadece düz konuşma dili kullan.
        ÜSLUP: Her cevap sıcak, nazik ve TAM CÜMLE olsun; tek kelimelik/telgraf gibi cevap verme. "Efendim" kelimesini virgülle ayırmadan, cümlenin doğal parçası olarak kullanabilirsin (ör. "Şu anda saat 10.19 efendim.").
        Fonksiyonların: get_weather (başka şehir/yarın/hafta sonu hava soruları), save_memory / delete_memory / list_memories (kullanıcı bir şeyi hatırlamanı ya da unutmanı isterse).
        Fotoğraf gelirse içeriğini incele ve kısaca anlat. Uydurma; bilmiyorsan dürüstçe söyle.

        CİHAZ BİLGİSİ: Tarih/saat: \(f.string(from: Date())). Cihaz: \(UIDevice.current.model), iOS \(UIDevice.current.systemVersion). Pil: \(battery).

        KALICI HAFIZA (kullanıcı silene kadar hatırlanır):
        \(memBlock)
        """
    }
}


extension UIImage {
    func resizedJPEG(maxSide: CGFloat, quality: CGFloat = 0.8) -> Data? {
        let longest = max(size.width, size.height)
        let scale = longest > maxSide ? maxSide / longest : 1
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        let img = UIGraphicsImageRenderer(size: newSize, format: fmt).image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
        return img.jpegData(compressionQuality: quality)
    }
}
