import SwiftUI

extension Color {
    init(hex: UInt32) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: 1)
    }
}

/// Android tarafındaki theme/Color.kt paletinin birebir karşılığı.
enum Theme {
    static let bg = Color(hex: 0x080F16)
    static let bgTop = Color(hex: 0x10202B)
    static let panel = Color(hex: 0x111D27)
    static let teal = Color(hex: 0x6FD3C8)
    static let tealDim = Color(hex: 0x2F5E63)
    static let tealMid = Color(hex: 0x16313A)
    static let text = Color(hex: 0xDDEFED)
    static let dim = Color(hex: 0x86A3A5)
    static let green = Color(hex: 0x7BE0AD)
    static let red = Color(hex: 0xFF7D8B)
    static let gold = Color(hex: 0xF2CC7A)
    static let blue = Color(hex: 0x8BB2FF)

    static var background: LinearGradient {
        LinearGradient(colors: [bgTop, bg], startPoint: .top, endPoint: .bottom)
    }
}
