import SwiftUI
import PhotosUI

struct MainView: View {
    @EnvironmentObject var vm: ChatViewModel
    @State private var input = ""
    @State private var attached: UIImage?
    @State private var showMenu = false
    @State private var showCamera = false
    @State private var showPhotos = false
    @State private var pickerItem: PhotosPickerItem?
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                VStack(spacing: 0) {
                    header
                    chatList
                    inputBar
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .sheet(isPresented: $showMenu) { SideMenu() }
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker { attached = $0 }.ignoresSafeArea()
        }
        .photosPicker(isPresented: $showPhotos, selection: $pickerItem, matching: .images)
        .onChange(of: pickerItem) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data) { attached = img }
                pickerItem = nil
            }
        }
    }

    private var header: some View {
        ZStack {
            OrbView(state: vm.orbState, level: CGFloat(vm.speech.level))
                .frame(height: 150)
            HStack {
                Button { showMenu = true } label: {
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 20, weight: .light))
                        .foregroundColor(Theme.teal)
                        .frame(width: 44, height: 44)
                }
                Spacer()
                if vm.speech.isSpeaking {
                    Button { vm.speech.stopSpeaking() } label: {
                        Image(systemName: "speaker.slash")
                            .foregroundColor(Theme.teal).frame(width: 44, height: 44)
                    }
                }
            }
            .padding(.horizontal, 8)
        }
        .padding(.top, 4)
    }

    private var chatList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(vm.messages) { m in bubble(m).id(m.id) }
                    if vm.isBusy {
                        HStack { ProgressView().tint(Theme.teal); Spacer() }.padding(.horizontal, 16)
                    }
                    if !vm.speech.partial.isEmpty {
                        Text(vm.speech.partial).font(.footnote).foregroundColor(Theme.dim)
                    }
                    Color.clear.frame(height: 1).id("bottom")
                }
                .padding(.vertical, 8)
            }
            .onChange(of: vm.messages.count) { _ in withAnimation { proxy.scrollTo("bottom") } }
            .onChange(of: vm.isBusy) { _ in withAnimation { proxy.scrollTo("bottom") } }
        }
    }

    private func bubble(_ m: ChatMessage) -> some View {
        let mine = m.role == "user"
        return HStack {
            if mine { Spacer(minLength: 48) }
            VStack(alignment: .leading, spacing: 6) {
                if let d = m.imageData, let img = UIImage(data: d) {
                    Image(uiImage: img).resizable().scaledToFit()
                        .frame(maxHeight: 180).clipShape(RoundedRectangle(cornerRadius: 12))
                }
                Text(m.text).foregroundColor(Theme.text).textSelection(.enabled)
            }
            .padding(12)
            .background(mine ? Theme.tealMid : Theme.panel.opacity(0.85))
            .clipShape(RoundedRectangle(cornerRadius: 18))
            if !mine { Spacer(minLength: 48) }
        }
        .padding(.horizontal, 12)
    }

    private var inputBar: some View {
        VStack(spacing: 6) {
            if let img = attached {
                HStack {
                    Image(uiImage: img).resizable().scaledToFill()
                        .frame(width: 56, height: 56).clipShape(RoundedRectangle(cornerRadius: 10))
                    Button { attached = nil } label: {
                        Image(systemName: "xmark.circle.fill").foregroundColor(Theme.dim)
                    }
                    Spacer()
                }
                .padding(.horizontal, 16)
            }
            HStack(alignment: .bottom, spacing: 8) {
                Menu {
                    Button { showCamera = true } label: { Label("Kamera", systemImage: "camera") }
                    Button { showPhotos = true } label: { Label("Fotoğraf", systemImage: "photo") }
                } label: { circleIcon("plus") }

                TextField("Judo'ya yaz…", text: $input, axis: .vertical)
                    .lineLimit(1...5)
                    .focused($focused)
                    .foregroundColor(Theme.text)
                    .padding(.horizontal, 14).padding(.vertical, 10)
                    .background(Theme.panel)
                    .clipShape(RoundedRectangle(cornerRadius: 20))

                Button { vm.speech.toggleListening() } label: {
                    circleIcon(vm.speech.isListening ? "stop.fill" : "mic")
                }

                Button {
                    vm.send(input, image: attached)
                    input = ""; attached = nil; focused = false
                } label: {
                    circleIcon("arrow.up", filled: true)
                }
                .disabled(vm.isBusy || (input.trimmingCharacters(in: .whitespaces).isEmpty && attached == nil))
            }
            .padding(.horizontal, 12).padding(.bottom, 8)
        }
    }

    private func circleIcon(_ name: String, filled: Bool = false) -> some View {
        Image(systemName: name)
            .font(.system(size: 17, weight: .medium))
            .foregroundColor(filled ? Theme.bg : Theme.teal)
            .frame(width: 42, height: 42)
            .background(filled ? Theme.teal : Theme.panel)
            .clipShape(Circle())
    }
}

/// Yan menü (Android'deki ☰ menüsünün karşılığı).
struct SideMenu: View {
    @EnvironmentObject var vm: ChatViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                NavigationLink("Hafıza") { MemoryView() }
                Section("Ses") {
                    Toggle("Cevapları sesli oku", isOn: $vm.speakReplies)
                    VStack(alignment: .leading) {
                        Text("Konuşma hızı").font(.footnote).foregroundColor(Theme.dim)
                        Slider(value: $vm.speechRate, in: 0.3...0.65)
                    }
                }
                Section {
                    Button("Sohbeti temizle", role: .destructive) { vm.clearChat(); dismiss() }
                    Button("Anahtarı değiştir") { vm.resetKey(); dismiss() }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle("Judo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Bitti") { dismiss() } } }
        }
        .presentationDetents([.medium, .large])
        .tint(Theme.teal)
    }
}
