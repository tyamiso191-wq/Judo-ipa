import Foundation

enum LlmError: LocalizedError {
    case noKey, auth, quota, http(Int, String), badResponse

    var errorDescription: String? {
        switch self {
        case .noKey: return "Gemini API anahtarı girilmemiş."
        case .auth: return "Gemini anahtarı geçersiz ya da erişimi kapalı."
        case .quota: return "Gemini kotası doldu, biraz sonra tekrar dene."
        case .http(let c, let m): return "Gemini hata verdi (HTTP \(c)). \(m)"
        case .badResponse: return "Gemini'den anlaşılmayan bir yanıt geldi."
        }
    }
}

enum KeyStatus: Equatable {
    case valid, invalid(String), unreachable(String)
}

/// Google Gemini, OpenAI uyumlu uç nokta (Android GeminiClient.kt karşılığı).
struct GeminiClient {
    static let baseURL = "https://generativelanguage.googleapis.com/v1beta"
    static let model = "gemini-2.5-flash"

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 120
        c.timeoutIntervalForResource = 150
        return URLSession(configuration: c)
    }()

    // MARK: Anahtar doğrulama

    func validate(_ key: String) async -> KeyStatus {
        let k = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !k.isEmpty else { return .invalid("API anahtarı boş.") }
        guard let url = URL(string: "\(Self.baseURL)/models?pageSize=1") else { return .unreachable("URL hatası") }
        var req = URLRequest(url: url)
        req.setValue(k, forHTTPHeaderField: "x-goog-api-key")
        do {
            let (data, resp) = try await session.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let low = (String(data: data, encoding: .utf8) ?? "").lowercased()
            switch code {
            case 200..<300, 429: return .valid
            case 401, 403: return .invalid("Bu Gemini anahtarı geçersiz ya da erişimi kapalı.")
            case 400 where low.contains("api key") || low.contains("api_key"):
                return .invalid("Bu Gemini anahtarı geçersiz. aistudio.google.com/apikey adresinden yenisini al.")
            default: return .unreachable("Gemini beklenmeyen yanıt verdi (HTTP \(code)).")
            }
        } catch {
            return .unreachable("Gemini'ye ulaşılamadı: \(error.localizedDescription)")
        }
    }

    // MARK: Sohbet (araç çağırma döngüsüyle)

    func chat(key: String,
              system: String,
              history: [ChatMessage],
              tools: [[String: Any]],
              runTool: (String, [String: Any]) async -> String) async throws -> String {
        var msgs: [[String: Any]] = [["role": "system", "content": system]]
        history.forEach { msgs.append(apiMessage($0)) }

        for _ in 0..<5 {
            let body: [String: Any] = ["model": Self.model, "messages": msgs, "tools": tools]
            let data = try await post("/openai/chat/completions", key: key, body: body)
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let choice = (json["choices"] as? [[String: Any]])?.first,
                  let message = choice["message"] as? [String: Any]
            else { throw LlmError.badResponse }

            if let calls = message["tool_calls"] as? [[String: Any]], !calls.isEmpty {
                msgs.append(message)
                for call in calls {
                    let id = (call["id"] as? String) ?? UUID().uuidString
                    let f = (call["function"] as? [String: Any]) ?? [:]
                    let name = (f["name"] as? String) ?? ""
                    var args: [String: Any] = [:]
                    if let s = f["arguments"] as? String, let d = s.data(using: .utf8),
                       let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] { args = o }
                    let result = await runTool(name, args)
                    msgs.append(["role": "tool", "tool_call_id": id, "name": name, "content": result])
                }
                continue
            }
            if let text = message["content"] as? String, !text.isEmpty { return text }
            throw LlmError.badResponse
        }
        throw LlmError.badResponse
    }

    private func apiMessage(_ m: ChatMessage) -> [String: Any] {
        if m.role == "user", let img = m.imageData {
            let b64 = img.base64EncodedString()
            return ["role": "user", "content": [
                ["type": "text", "text": m.text],
                ["type": "image_url", "image_url": ["url": "data:image/jpeg;base64,\(b64)"]]
            ]]
        }
        return ["role": m.role, "content": m.text]
    }

    private func post(_ path: String, key: String, body: [String: Any]) async throws -> Data {
        guard let url = URL(string: Self.baseURL + path) else { throw LlmError.badResponse }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, resp) = try await session.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        switch code {
        case 200..<300: return data
        case 401, 403: throw LlmError.auth
        case 429: throw LlmError.quota
        default:
            let msg = String((String(data: data, encoding: .utf8) ?? "").prefix(200))
            throw LlmError.http(code, msg)
        }
    }
}
