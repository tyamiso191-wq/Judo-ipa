import Foundation

/// Gemini'ye sunulan araçlar (function calling): hafıza + hava durumu.
enum Tools {
    static let definitions: [[String: Any]] = [
        fn("save_memory",
           "Kullanıcının kalıcı olarak hatırlanmasını istediği bir bilgiyi kaydeder (ör. kedimin adı Pamuk).",
           ["text": ["type": "string", "description": "Kaydedilecek not"]], ["text"]),
        fn("delete_memory",
           "Kayıtlı bir hafıza notunu id'si ya da içerdiği metinle siler.",
           ["query": ["type": "string", "description": "Not id'si veya notta geçen metin"]], ["query"]),
        fn("list_memories", "Kayıtlı tüm hafıza notlarını listeler.", [:], []),
        fn("get_weather",
           "Bir şehir için güncel hava durumu ve 3 günlük tahmini getirir.",
           ["city": ["type": "string", "description": "Şehir adı, ör. İstanbul"]], ["city"])
    ]

    private static func fn(_ name: String, _ desc: String,
                           _ props: [String: Any], _ required: [String]) -> [String: Any] {
        ["type": "function",
         "function": ["name": name, "description": desc,
                      "parameters": ["type": "object", "properties": props, "required": required]]]
    }

    static func run(_ name: String, _ args: [String: Any]) async -> String {
        switch name {
        case "save_memory":
            let t = (args["text"] as? String) ?? ""
            guard !t.trimmingCharacters(in: .whitespaces).isEmpty else { return "Hata: boş not." }
            let id = MemoryStore.add(t)
            return "Kaydedildi (id: \(id))."
        case "delete_memory":
            let n = MemoryStore.delete((args["query"] as? String) ?? "")
            return n > 0 ? "\(n) not silindi." : "Eşleşen not bulunamadı."
        case "list_memories":
            let items = MemoryStore.list()
            return items.isEmpty ? "Hafıza boş." : items.map { "[\($0.id)] \($0.text)" }.joined(separator: "\n")
        case "get_weather":
            return await weather((args["city"] as? String) ?? "")
        default:
            return "Bilinmeyen araç: \(name)"
        }
    }

    /// Open-Meteo (anahtarsız).
    private static func weather(_ city: String) async -> String {
        guard !city.isEmpty,
              let enc = city.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let gURL = URL(string: "https://geocoding-api.open-meteo.com/v1/search?name=\(enc)&count=1&language=tr")
        else { return "Hata: şehir adı geçersiz." }
        do {
            let (gData, _) = try await URLSession.shared.data(from: gURL)
            guard let g = try JSONSerialization.jsonObject(with: gData) as? [String: Any],
                  let r = (g["results"] as? [[String: Any]])?.first,
                  let lat = r["latitude"] as? Double, let lon = r["longitude"] as? Double
            else { return "Şehir bulunamadı: \(city)" }
            let place = (r["name"] as? String) ?? city
            let u = "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)"
                + "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
                + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                + "&timezone=auto&forecast_days=3"
            guard let url = URL(string: u) else { return "Hata." }
            let (data, _) = try await URLSession.shared.data(from: url)
            let text = String(data: data, encoding: .utf8) ?? ""
            return "Yer: \(place). Open-Meteo verisi (weather_code WMO kodudur): \(text.prefix(1500))"
        } catch {
            return "Hava durumu alınamadı: \(error.localizedDescription)"
        }
    }
}
